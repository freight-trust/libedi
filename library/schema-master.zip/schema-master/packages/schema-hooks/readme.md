# @feathersjs/schema-hooks

Hooks for use `@feathersjs/schema`.
